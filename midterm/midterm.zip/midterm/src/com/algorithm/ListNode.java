package com.algorithm;

public class ListNode {


    int val;
    ListNode next;


//    public ListNode(ListNode next) {
//        this.next = next;
//    }

    public ListNode(int val) {
        this.val = val;
    }
}
