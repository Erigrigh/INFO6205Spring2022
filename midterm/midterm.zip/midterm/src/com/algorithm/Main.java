package com.algorithm;

public class Main {

    public static void main(String[] args) {
     int[] nums = new int[]{0, 1, 3, 50, 75};

        int[] num = new int[]{-1};

     Question1 q1 = new Question1();
     q1.missingNumber(nums, 0, 99 );

        q1.missingNumber(num, -1, -1 );

    }
}
